"use strict";
const wrapperImg = document.querySelector(".slider-image");
const imgs = [
  "images/1.jpg",
  "images/2.jpg",
  "images/3.jpg",
  "images/4.jpg",
  "images/5.jpg",
  "images/6.jpg",
  "images/7.jpg",
  "images/8.jpg",
];
const btnPrev = document.querySelector(".prev");
const btnNext = document.querySelector(".next");
const dots = document.querySelector(".dots");
let currentSlide = 0;

//Добавил функцию для интервала
let interval = 0;
function intervalSlider() {
  clearInterval(interval);
  interval = setInterval(() => {
    ++currentSlide;
    slider(currentSlide);
    activeDot(currentSlide);
    isLastSlide();
    isFirstSlide();
  }, 5000);
}
intervalSlider();

//Функция, чтобы удалить интервал
function deleteInterval() {
  clearInterval(interval);
}

function addImagesToSlider() {
  imgs.forEach((img, i) => {
    let tagImg = document.createElement("img");
    tagImg.setAttribute("alt", "slide " + i + 1);
    tagImg.setAttribute("src", img);
    wrapperImg.appendChild(tagImg);
  });
}

function slider(index) {
  const allImg = document.querySelectorAll(".slider-image img");
  allImg.forEach((img) => {
    img.style.display = "none";
  });
  allImg[index].style.display = "block";
  //добавлено условие и функция deleteInterval
  if (index === imgs.length - 1) {
    deleteInterval();
  }
}

function addDots() {
  let newUl = document.createElement("ul");
  imgs.forEach((img, i) => {
    let dot = document.createElement("li");
    dot.classList.add("dot");
    dot.setAttribute("data-index", i);
    newUl.appendChild(dot);
  });
  dots.appendChild(newUl);
}

function isLastSlide() {
  if (currentSlide === imgs.length - 1) {
    btnNext.setAttribute("disabled", "disabled");
  } else {
    btnNext.removeAttribute("disabled");
  }
}

function isFirstSlide() {
  if (currentSlide === 0) {
    btnPrev.setAttribute("disabled", "disabled");
  } else {
    btnPrev.removeAttribute("disabled");
  }
}

function activeDot() {
  const dotsSlider = document.querySelectorAll(".dots .dot");
  dotsSlider.forEach((dot) => {
    dot.classList.remove("active");
  });
  dotsSlider[currentSlide].classList.add("active");
}

addImagesToSlider();
slider(currentSlide);
addDots();
isFirstSlide();
activeDot();

btnNext.addEventListener("click", function () {
  slider(++currentSlide);
  isLastSlide();
  isFirstSlide();
  activeDot();
  intervalSlider(); //добавлена функция intervalSlider()
});

btnPrev.addEventListener("click", function () {
  slider(--currentSlide);
  isLastSlide();
  isFirstSlide();
  activeDot();
  intervalSlider(); //добавлена функция intervalSlider()
});

dots.addEventListener("click", function (e) {
  let target = e.target;
  if (target.classList.contains("dot")) {
    let index = +target.getAttribute("data-index");
    slider(index);
    currentSlide = index;
    isLastSlide();
    isFirstSlide();
    activeDot();
    intervalSlider(index);
  }
});
